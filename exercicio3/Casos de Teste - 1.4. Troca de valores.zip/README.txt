Arquivo zip gerado em: 25/06/2021 13:16:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 1.4. Troca de valores